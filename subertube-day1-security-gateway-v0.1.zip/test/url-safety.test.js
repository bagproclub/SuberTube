import test from 'node:test';
import assert from 'node:assert/strict';
import { validateAndNormalizeUrl } from '../src/url-safety.js';

test('accepts a normal HTTPS URL and removes fragments', async () => {
  const value = await validateAndNormalizeUrl('https://192.0.2.1/watch?id=1#section');
  assert.equal(value, 'https://192.0.2.1/watch?id=1');
});

test('rejects unsupported protocols', async () => {
  await assert.rejects(() => validateAndNormalizeUrl('javascript:alert(1)'), /Only http and https/);
});

test('rejects embedded credentials', async () => {
  await assert.rejects(() => validateAndNormalizeUrl('https://user:pass@example.com/'), /credentials/);
});

test('rejects loopback and private IP literals', async () => {
  await assert.rejects(() => validateAndNormalizeUrl('http://127.0.0.1/'), /not allowed/);
  await assert.rejects(() => validateAndNormalizeUrl('http://192.168.1.10/'), /not allowed/);
});
