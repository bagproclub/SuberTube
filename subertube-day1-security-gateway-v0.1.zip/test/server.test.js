import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { spawn } from 'node:child_process';

function request(port, path, method, body) {
  return new Promise((resolve, reject) => {
    const req = http.request({
      host: '127.0.0.1',
      port,
      path,
      method,
      headers: { 'Content-Type': 'application/json' }
    }, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(Buffer.concat(chunks)) }));
    });
    req.on('error', reject);
    if (body !== undefined) req.write(JSON.stringify(body));
    req.end();
  });
}

test('health endpoint works and URL endpoint fails closed when provider is unconfigured', async () => {
  const port = 18080 + Math.floor(Math.random() * 500);
  const child = spawn(process.execPath, ['src/server.js'], {
    cwd: process.cwd(),
    env: { ...process.env, APP_HOST: '127.0.0.1', APP_PORT: String(port) },
    stdio: ['ignore', 'pipe', 'pipe']
  });

  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => resolve(), 1000);
    child.stdout.on('data', data => {
      if (String(data).includes('listening')) {
        clearTimeout(timer);
        resolve();
      }
    });
    child.on('error', reject);
  });

  try {
    const health = await request(port, '/healthz', 'GET');
    assert.equal(health.status, 200);
    assert.equal(health.body.ok, true);

    const check = await request(port, '/v1/url/check', 'POST', { url: 'https://192.0.2.1/' });
    assert.equal(check.status, 503);
    assert.equal(check.body.error, 'PROVIDER_NOT_CONFIGURED');
    assert.equal(check.body.verdict, 'unknown');
  } finally {
    child.kill('SIGTERM');
  }
});
