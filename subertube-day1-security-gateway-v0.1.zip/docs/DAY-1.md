# SuberTube — Day 1: Security Gateway Foundation

## Goal

Create a small, testable boundary for URL safety without placing Malwarebytes credentials in the client or inventing a production provider API contract.

## Implemented

- HTTP security gateway skeleton.
- `POST /v1/url/check` contract.
- Strict HTTP/HTTPS URL validation.
- URL credential rejection.
- Loopback/private/link-local/multicast target rejection.
- DNS resolution check before any future outbound request.
- JSON body size limit.
- Fail-closed provider state when Malwarebytes runtime integration is not configured.
- Security response headers and `no-store` cache policy.
- Domain/hosting architecture placeholder using `https://subertube.example` as documentation-only host.

## Intentionally not implemented

- Production domain registration.
- DNS changes.
- Cloudflare account changes.
- Production hosting.
- Production secrets.
- Direct Malwarebytes API integration, because the available development connector verifies indicators but does not establish a deployable application API credential/contract.

## Verification order

1. `npm run check`
2. `npm test`
3. Start server.
4. Check `/healthz`.
5. Check URL validation failure modes.
6. Replace the provider adapter only after the official integration contract and secret boundary are selected.
