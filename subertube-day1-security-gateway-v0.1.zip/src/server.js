import http from 'node:http';
import { validateAndNormalizeUrl, UrlValidationError } from './url-safety.js';
import { MalwarebytesProvider, ProviderNotConfiguredError } from './providers/malwarebytes.js';

const HOST = process.env.APP_HOST ?? '127.0.0.1';
const PORT = Number(process.env.APP_PORT ?? 8080);
const provider = new MalwarebytesProvider();

function sendJson(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer'
  });
  res.end(payload);
}

async function readBody(req) {
  return await new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', chunk => {
      size += chunk.length;
      if (size > 32 * 1024) {
        reject(new Error('BODY_TOO_LARGE'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(new Error('INVALID_JSON'));
      }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'GET' && req.url === '/healthz') {
    return sendJson(res, 200, { ok: true, service: 'subertube-security-gateway' });
  }

  if (req.method !== 'POST' || req.url !== '/v1/url/check') {
    return sendJson(res, 404, { error: 'NOT_FOUND' });
  }

  try {
    const body = await readBody(req);
    const normalizedUrl = await validateAndNormalizeUrl(body?.url);

    try {
      const result = await provider.checkUrl(normalizedUrl);
      return sendJson(res, 200, {
        url: normalizedUrl,
        verdict: result.verdict,
        action: result.action,
        provider: result.provider
      });
    } catch (error) {
      if (error instanceof ProviderNotConfiguredError) {
        return sendJson(res, 503, {
          error: 'PROVIDER_NOT_CONFIGURED',
          url: normalizedUrl,
          verdict: 'unknown',
          action: 'manual_review',
          provider: 'malwarebytes-boundary'
        });
      }
      throw error;
    }
  } catch (error) {
    if (error instanceof UrlValidationError) {
      return sendJson(res, 400, { error: error.code, message: error.message });
    }
    if (error?.message === 'INVALID_JSON') {
      return sendJson(res, 400, { error: 'INVALID_JSON' });
    }
    if (error?.message === 'BODY_TOO_LARGE') {
      return sendJson(res, 413, { error: 'BODY_TOO_LARGE' });
    }
    return sendJson(res, 500, { error: 'INTERNAL_ERROR' });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`SuberTube security gateway listening on http://${HOST}:${PORT}`);
});
