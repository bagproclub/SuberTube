import net from 'node:net';
import dns from 'node:dns/promises';

export class UrlValidationError extends Error {
  constructor(message, code = 'INVALID_URL') {
    super(message);
    this.name = 'UrlValidationError';
    this.code = code;
  }
}

function isBlockedIp(ip) {
  const version = net.isIP(ip);
  if (version === 4) {
    const [a, b] = ip.split('.').map(Number);
    return (
      a === 0 ||
      a === 10 ||
      a === 127 ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 100 && b >= 64 && b <= 127) ||
      a >= 224
    );
  }
  if (version === 6) {
    const normalized = ip.toLowerCase();
    return (
      normalized === '::' ||
      normalized === '::1' ||
      normalized.startsWith('fc') ||
      normalized.startsWith('fd') ||
      normalized.startsWith('fe80:')
    );
  }
  return false;
}

export async function validateAndNormalizeUrl(input) {
  if (typeof input !== 'string' || input.length === 0 || input.length > 4096) {
    throw new UrlValidationError('URL must be a non-empty string up to 4096 characters.');
  }

  let parsed;
  try {
    parsed = new URL(input);
  } catch {
    throw new UrlValidationError('URL syntax is invalid.');
  }

  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new UrlValidationError('Only http and https URLs are supported.', 'UNSUPPORTED_SCHEME');
  }

  if (parsed.username || parsed.password) {
    throw new UrlValidationError('Embedded URL credentials are not allowed.', 'URL_CREDENTIALS_FORBIDDEN');
  }

  if (parsed.hostname === 'localhost' || parsed.hostname.endsWith('.localhost')) {
    throw new UrlValidationError('Localhost targets are not allowed.', 'LOCAL_TARGET_BLOCKED');
  }

  if (net.isIP(parsed.hostname)) {
    if (isBlockedIp(parsed.hostname)) {
      throw new UrlValidationError('Private, loopback, link-local, or multicast IP targets are not allowed.', 'PRIVATE_TARGET_BLOCKED');
    }
  } else {
    // Resolve before any future outbound HTTP call. The current Day 1 service does not
    // fetch the target; this lookup protects the boundary when an HTTP client is added.
    const answers = await dns.lookup(parsed.hostname, { all: true, verbatim: true });
    if (answers.some(({ address }) => isBlockedIp(address))) {
      throw new UrlValidationError('Hostname resolves to a private or local network target.', 'PRIVATE_DNS_TARGET_BLOCKED');
    }
  }

  parsed.hash = '';
  return parsed.toString();
}
