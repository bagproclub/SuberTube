# SuberTube — Security Gateway Day 1

This repository is a minimal implementation scaffold for the architecture:

`Internet → Domain / DNS → Edge / Proxy → SuberTube Hosting → Backend → Application`

and the security path:

`DOMAIN CONTROL → URL SAFETY (Malwarebytes boundary) → SuberTube Backend → Application / App`

## Important domain note

`https://subertube.example` is a documentation placeholder. IANA reserves example domains for documentation and they are not available for registration or production use.

## Run

```bash
npm run check
npm test
npm start
```

The URL safety provider is deliberately unconfigured on Day 1. No production credential is stored in this repository.
